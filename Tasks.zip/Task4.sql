use course_work;
drop procedure if exists task4_1;
DELIMITER //
CREATE PROCEDURE Task4_1 (item VARCHAR(45))
BEGIN
	SELECT Count, Price FROM nomenclature where Name_product = item;
END //
DELIMITER ;
call Task4_1 ('avocado');

use coursework;
drop procedure if exists task4_2;
DELIMITER //
CREATE PROCEDURE Task4_2 (item VARCHAR(45), outlet VARCHAR(45))
BEGIN
	SELECT Count, Price FROM nomenclature where Name_product = item and OutletType = outlet;
END //
DELIMITER ;
call Task4_2 ('avocado', 'shop');

use coursework;
drop procedure if exists task4_3;
DELIMITER //
CREATE PROCEDURE Task4_3 (item VARCHAR(45), outlet VARCHAR(45), id VARCHAR(45))
BEGIN
	SELECT Count, Price FROM nomenclature where Name_product = item and OutletType = outlet and IDoutlet = id;
END //
DELIMITER ;
call Task4_3 ('cheese', 'shop', 102);