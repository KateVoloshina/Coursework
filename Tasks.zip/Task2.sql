use course_work;
drop procedure if exists task2_1;
DELIMITER //
CREATE PROCEDURE Task2_1 (item VARCHAR(45), dat INT)
BEGIN
    SELECT NameBuyer FROM accounting where Product = item and Timedata = dat;
    SELECT COUNT(NameBuyer) FROM accounting where Product = item and Timedata = dat;
END //
DELIMITER ;
CALL Task2_1 ('avocado', 1);

use course_work;
drop procedure if exists task2_2;
DELIMITER //
CREATE PROCEDURE Task2_2 (num INT)
BEGIN
    SELECT NameBuyer FROM accounting where Number >= num;
    SELECT COUNT(NameBuyer) FROM accounting where Number >= num;
END //
DELIMITER ;
CALL Task2_2 ('2');