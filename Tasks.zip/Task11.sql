use course_work;
drop procedure if exists task11;
DELIMITER //
CREATE PROCEDURE Task11 (dat INT)
BEGIN
    SELECT Sum(Number), Sum(AdditionalSpending), Sum(Rent), Sum(Salary) FROM Sellers
    JOIN Outlets ON Outlets_ID = ID_outlet and WorkTime = dat;
END //
DELIMITER ;
call Task11 (12);