use course_work;

INSERT accounting(ID_Buyer, NameBuyer, TypeOutlet, IDoutlets, Product, Number, Payment, Timedata) 
VALUES (4, 'Mr. Blue', 'emporium', 101, 'bun', 2, 15, 3);

INSERT nomenclature(ID_product, Name_product, Count, Price, IDoutlet, OutletType) 
VALUES (8, 'wine', 5, 200, 101, 'emporium');

INSERT outlets(ID_outlet, Outlet_type, FloorNumber, SectionsNumb, SectionManager, HallsNumb, SellersNumb, Size, Rent, AdditionalSpending, CounterNumb, WorkTime) 
VALUES (105, 'stand', 1, 1, '-', 1, 1, 18, 0, 0, 1, 3);

INSERT requests(IDrequest, Supplier, Name_product, Number, Price, WorkTime) 
VALUES (17, 'WineRain', 'wine', 2, 101, 3);

INSERT sellers(ID_seller, Full_name, Outlet_type, Outlet_ID, Sold_item, Number, Price, WorkTime, Salary) 
VALUES (8, 'Mr. Yellow', 101, 'emporium', 'wine', 2, 200, 6, 6000);

INSERT suppliers(ID, Full_name, Name_product, MinNumber, Price, WorkTime) 
VALUES (8, 'WineRain', 'wine', 6, 200, 3);

UPDATE nomenclature
SET Number = Number - 3
WHERE Product = 'avocado' and TypeOutlet = 'emporium' and IDoutlets = 101;

UPDATE nomeclature
SET Price = Price + 3
WHERE Product = 'avocado' and TypeOutlet = 'shop' and IDoutlets = 102;

DELIMITER //
CREATE TRIGGER SelDel AFTER delete ON suppliers
FOR EACH ROW
BEGIN
	DELETE FROM requests WHERE Supplier = old.Full_name;
END//
DELETE FROM suppliers WHERE Full_name = 'WineRain';