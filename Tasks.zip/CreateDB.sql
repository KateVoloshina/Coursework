DROP SCHEMA IF EXISTS `Course_Work` ;

CREATE SCHEMA IF NOT EXISTS `Course_Work` DEFAULT CHARACTER SET utf8 ;
USE `Course_Work` ;

DROP TABLE IF EXISTS `Course_Work`.`Sellers` ;
CREATE TABLE IF NOT EXISTS `Course_Work`.`Sellers` (
  `ID_seller` INT NULL,
  `Full_name` VARCHAR(20) NULL,
  `Outlets_type` VARCHAR(45) NULL,
  `Outlets_ID` INT NULL,
  `Sold_item` VARCHAR(45) NULL,
  `Number` INT NULL,
  `Price` INT NULL,
  `Work_time` VARCHAR(45) NULL,
  `Salary` INT NULL)
ENGINE = InnoDB;

DROP TABLE IF EXISTS `Course_Work`.`Suppliers` ;
CREATE TABLE IF NOT EXISTS `Course_Work`.`Suppliers` (
  `ID` INT NULL,
  `Full_name` VARCHAR(45) NULL,
  `Name_product` VARCHAR(45) NULL,
  `MinNumber` INT NULL,
  `Price` INT NULL,
  `WorkTime` INT NULL)
ENGINE = InnoDB;

DROP TABLE IF EXISTS `Course_Work`.`Outlets` ;
CREATE TABLE IF NOT EXISTS `Course_Work`.`Outlets` (
  `ID_outlet` INT NULL,
  `Outlet_type` VARCHAR(20) NULL,
  `FloorNumber` INT NULL,
  `SectionsNumb` INT NULL,
  `SectionManager` VARCHAR(20) NULL,
  `HallsNumb` INT NULL,
  `SellersNumb` INT NULL,
  `Size` INT NULL,
  `Rent` INT NULL,
  `AdditionalSpending` INT NULL,
  `CounterNumb` INT NULL,
  `WorkTime` INT NULL)
ENGINE = InnoDB;

DROP TABLE IF EXISTS `Course_Work`.`Nomenclature` ;
CREATE TABLE IF NOT EXISTS `Course_Work`.`Nomenclature` (
  `ID_product` INT NULL,
  `Name_product` VARCHAR(50) NULL,
  `Count` INT NULL,
  `Price` INT NULL,
  `IDoutlet` INT NULL,
  `OutletType` VARCHAR(45) NULL)
ENGINE = InnoDB;

DROP TABLE IF EXISTS `Course_Work`.`Accounting` ;
CREATE TABLE IF NOT EXISTS `Course_Work`.`Accounting` (
  `ID_Buyer` INT NULL,
  `NameBuyer` VARCHAR(50) NULL,
  `TypeOutlet` VARCHAR(50) NULL,
  `IDoutlets` INT NULL,
  `Product` VARCHAR(45) NULL,
  `Number` INT NULL,
  `Payment` INT NULL,
  `Timedata` VARCHAR(45) NULL)
ENGINE = InnoDB;


DROP TABLE IF EXISTS `Course_Work`.`Requests` ;
CREATE TABLE IF NOT EXISTS `Course_Work`.`Requests` (
  `IDrequest` INT NULL,
  `Supplier` VARCHAR(50) NULL,
  `Name_product` VARCHAR(50) NULL,
  `Number` INT NULL,
  `Price` INT NULL,
  `WorkTime` INT NULL)
ENGINE = InnoDB;