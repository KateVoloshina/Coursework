use course_work;
drop procedure if exists task10_1;
DELIMITER //
CREATE PROCEDURE Task10_1 (num varchar(45))
BEGIN
    SELECT Sum(Number), Sum(Size) FROM Sellers JOIN Outlets ON Outlets_ID = ID_outlet;
END //
DELIMITER 
call Task10_1 ('sales volume / area');

use course_work;
drop procedure if exists task10_2;
DELIMITER //
CREATE PROCEDURE Task10_2 (num varchar(45))
BEGIN
    SELECT Sum(Number), Sum(HallsNumb) FROM Sellers JOIN Outlets ON Outlets_ID = ID_outlet;
END //
DELIMITER ;
call Task10_2 ('sales volume / number halls');

use course_work;
drop procedure if exists task10_3;
DELIMITER //
CREATE PROCEDURE Task10_3 (num varchar(45))
BEGIN
    SELECT Sum(Number), Sum(CounterNumb) FROM Sellers JOIN Outlets ON Outlets_ID = ID_outlet and Outlets_type = num;
END //
DELIMITER ;
call Task10_3 ('stand');

use course_work;
drop procedure if exists task10_4;
DELIMITER //
CREATE PROCEDURE Task10_4 (num varchar(45), nam varchar(45))
BEGIN
    SELECT Sum(Number), Sum(Salary) FROM Sellers JOIN Outlets ON Outlets_ID = ID_outlet and Outlets_type = num and Full_Name = nam;
END //
DELIMITER ;
call Task10_4 ('stand', 'Mr. Gaave');