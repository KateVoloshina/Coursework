use course_work;
drop procedure if exists task7_1;
DELIMITER //
CREATE PROCEDURE Task7_1 (nam VARCHAR(45), dat INT)
BEGIN
	SELECT Sold_item, Number FROM sellers where Sold_item = nam and Work_time = dat;
END //
DELIMITER ;
call Task7_1 ('avocado', 2);

use course_work;
drop procedure if exists task7_2;
DELIMITER //
CREATE PROCEDURE Task7_2 (nam VARCHAR(45), dat INT, outlet VARCHAR(45))
BEGIN
	SELECT Sold_item, Number FROM sellers where Sold_item = nam and Work_time = dat and Outlets_type = outlet;
END //
DELIMITER ;
call Task7_2 ('bun', 3, 'kiosk');

use course_work;
drop procedure if exists task7_3;
DELIMITER //
CREATE PROCEDURE Task7_3 (nam VARCHAR(45), dat INT, outlet VARCHAR(45), id INT)
BEGIN
	SELECT Sold_item, Number FROM sellers where Sold_item = nam and Work_time = dat and Outlets_type = outlet and Outlets_id = id;
END //
DELIMITER ;
call Task7_3 ('donut', 5, 'stand', 104);