use course_work;
drop procedure if exists task9_1;
DELIMITER //
CREATE PROCEDURE Task9_1 (nam VARCHAR(45), ful VARCHAR(45))
BEGIN
    SELECT Price FROM Suppliers where Name_product = nam and Full_name = ful;
END //
DELIMITER ;
call Task9_1 ('donut', 'Desert_Dessert');

use course_work;
drop procedure if exists task9_2;
DELIMITER //
CREATE PROCEDURE Task9_2 (nam VARCHAR(45), ful VARCHAR(45), dat INT)
BEGIN
    SELECT Price FROM Suppliers where Name_product = nam and Full_name = ful and WorkTime = dat;
END //
DELIMITER ;
call Task9_2 ('bun', 'Desert_Dessert', 12);