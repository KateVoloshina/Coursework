use course_work;
drop procedure if exists task15_1;
DELIMITER //
CREATE PROCEDURE Task15_1 (num INT)
BEGIN
    SELECT Requests.Name_product as Товар, Requests.Number as ПолученноеКоличество, Count as ЯвноеКоличество, IDoutlet as Точка FROM Requests
    JOIN nomenclature ON Requests.Name_product = nomenclature.Name_product where WorkTime = 2;
END //
DELIMITER ;
call Task15_1 (2);

use course_work;
drop procedure if exists task15_2;
DELIMITER //
CREATE PROCEDURE Task15_2 (num INT, id int)
BEGIN
    SELECT Requests.Name_product as Товар, Requests.Number as ПолученноеКоличество, Count as НынешнееКоличество, IDoutlet as Точка FROM Requests
    JOIN nomenclature ON Requests.Name_product = nomenclature.Name_product where WorkTime = 2 and IDoutlet = id;
END //
DELIMITER ;
call Task15_2 (2, 104);