use course_work;
drop procedure if exists task12;
DELIMITER //
CREATE PROCEDURE Task12 (num INT)
BEGIN
    SELECT * FROM Requests where IDrequest = num;
END //
DELIMITER ;
CALL Task12 (4);