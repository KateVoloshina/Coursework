use course_work;
drop procedure if exists task8_1;
DELIMITER //
CREATE PROCEDURE Task8_1 (something VARCHAR(45))
BEGIN
	SELECT Salary, Outlets_type, Outlets_ID FROM sellers;
END //
DELIMITER ;
call Task8_1 ('all salary');

use course_work;
drop procedure if exists task8_2;
DELIMITER //
CREATE PROCEDURE Task8_2 (typ VARCHAR(45))
BEGIN
	SELECT Salary, Outlets_type, Outlets_ID FROM sellers where Outlets_type = typ;
END //
DELIMITER ;
call Task8_2 ('shop');

use course_work;
drop procedure if exists task8_3;
DELIMITER //
CREATE PROCEDURE Task8_3 (typ VARCHAR(45), id INT)
BEGIN
	SELECT Salary, Outlets_type, Outlets_ID FROM sellers where Outlets_type = typ and Outlets_ID = id;
END //
DELIMITER ;
call Task8_3 ('stand', 104);