USE `Course_Work` ;

START TRANSACTION;
INSERT INTO `Course_Work`.`Sellers` (`ID_seller`, `Full_name`, `Outlets_type`, `Outlets_ID`, `Sold_item`, `Number`, `Price`, `Work_time`, `Salary`) VALUES (450, 'Mr. Richard', 'emporium', 101, 'avocado', 10, 50, '2', 6000);
INSERT INTO `Course_Work`.`Sellers` (`ID_seller`, `Full_name`, `Outlets_type`, `Outlets_ID`, `Sold_item`, `Number`, `Price`, `Work_time`, `Salary`) VALUES (451, 'Mr. Oof', 'kiosk', 103, 'bun', 16, 20, '3', 5000);
INSERT INTO `Course_Work`.`Sellers` (`ID_seller`, `Full_name`, `Outlets_type`, `Outlets_ID`, `Sold_item`, `Number`, `Price`, `Work_time`, `Salary`) VALUES (452, 'Mr. York', 'emporium', 101, 'avocado', 1, 50, '4', 6000);
INSERT INTO `Course_Work`.`Sellers` (`ID_seller`, `Full_name`, `Outlets_type`, `Outlets_ID`, `Sold_item`, `Number`, `Price`, `Work_time`, `Salary`) VALUES (453, 'Mr. Gaave', 'stand', 104, 'donut', 13, 16, '5', 4500);
INSERT INTO `Course_Work`.`Sellers` (`ID_seller`, `Full_name`, `Outlets_type`, `Outlets_ID`, `Sold_item`, `Number`, `Price`, `Work_time`, `Salary`) VALUES (454, 'Mr. Batle', 'kiosk', 103, 'bun', 7, 20, '6', 5000);
INSERT INTO `Course_Work`.`Sellers` (`ID_seller`, `Full_name`, `Outlets_type`, `Outlets_ID`, `Sold_item`, `Number`, `Price`, `Work_time`, `Salary`) VALUES (455, 'Mr. Inn', 'shop', 102, 'avocado', 8, 55, '12', 5500);
INSERT INTO `Course_Work`.`Sellers` (`ID_seller`, `Full_name`, `Outlets_type`, `Outlets_ID`, `Sold_item`, `Number`, `Price`, `Work_time`, `Salary`) VALUES (456, 'Mr. Vainn', 'shop', 102, 'cheese', 9, 100, '1', 5500);

COMMIT;

START TRANSACTION;
INSERT INTO `Course_Work`.`Suppliers` (`ID`, `Full_name`, `Name_product`, `MinNumber`, `Price`, `WorkTime`) VALUES (1717, 'JuicyFruits', 'avocado', 10, 45, 1);
INSERT INTO `Course_Work`.`Suppliers` (`ID`, `Full_name`, `Name_product`, `MinNumber`, `Price`, `WorkTime`) VALUES (1717, 'JuicyFruits', 'grapes', 10, 50, 1);
INSERT INTO `Course_Work`.`Suppliers` (`ID`, `Full_name`, `Name_product`, `MinNumber`, `Price`, `WorkTime`) VALUES (1719, 'Best_Bakery_Items', 'bun', 10, 15, 4);
INSERT INTO `Course_Work`.`Suppliers` (`ID`, `Full_name`, `Name_product`, `MinNumber`, `Price`, `WorkTime`) VALUES (1719, 'Best_Bakery_Items', 'donut', 17, 14, 4);
INSERT INTO `Course_Work`.`Suppliers` (`ID`, `Full_name`, `Name_product`, `MinNumber`, `Price`, `WorkTime`) VALUES (1720, 'NaturalProduction', 'cheese', 5, 42, 6);
INSERT INTO `Course_Work`.`Suppliers` (`ID`, `Full_name`, `Name_product`, `MinNumber`, `Price`, `WorkTime`) VALUES (1721, 'Desert_Dessert', 'bun', 15, 19, 12);
INSERT INTO `Course_Work`.`Suppliers` (`ID`, `Full_name`, `Name_product`, `MinNumber`, `Price`, `WorkTime`) VALUES (1721, 'Desert_Dessert', 'donut', 15, 10, 12);
INSERT INTO `Course_Work`.`Suppliers` (`ID`, `Full_name`, `Name_product`, `MinNumber`, `Price`, `WorkTime`) VALUES (1721, 'Desert_Dessert', 'cinnabonroll', 10, 17, 12);

COMMIT;

START TRANSACTION;
INSERT INTO `Course_Work`.`Outlets` (`ID_outlet`, `Outlet_type`, `FloorNumber`, `SectionsNumb`, `SectionManager`, `HallsNumb`, `SellersNumb`, `Size`, `Rent`, `AdditionalSpending`, `CounterNumb`, `WorkTime`) VALUES (101, 'Emporium', 6, 3, 'Mrs. Black ', 4, 3, 500, 40000, 10000, 3, 12);
INSERT INTO `Course_Work`.`Outlets` (`ID_outlet`, `Outlet_type`, `FloorNumber`, `SectionsNumb`, `SectionManager`, `HallsNumb`, `SellersNumb`, `Size`, `Rent`, `AdditionalSpending`, `CounterNumb`, `WorkTime`) VALUES (102, 'Shop', 1, 1, '-', 2, 2, 250, 4000, 1000, 4, 12);
INSERT INTO `Course_Work`.`Outlets` (`ID_outlet`, `Outlet_type`, `FloorNumber`, `SectionsNumb`, `SectionManager`, `HallsNumb`, `SellersNumb`, `Size`, `Rent`, `AdditionalSpending`, `CounterNumb`, `WorkTime`) VALUES (103, 'Kiosk', 1, 1, '-', 1, 1, 50, 400, 100, 2, 6);
INSERT INTO `Course_Work`.`Outlets` (`ID_outlet`, `Outlet_type`, `FloorNumber`, `SectionsNumb`, `SectionManager`, `HallsNumb`, `SellersNumb`, `Size`, `Rent`, `AdditionalSpending`, `CounterNumb`, `WorkTime`) VALUES (104, 'Stand', 1, 1, '-', 1, 1, 20, 0, 0, 1, 3);

COMMIT;

START TRANSACTION;
INSERT INTO `Course_Work`.`Nomenclature` (`ID_product`, `Name_product`, `Count`, `Price`, `IDoutlet`, `OutletType`) VALUES (1, 'avocado', 10, 55, 102, 'shop');
INSERT INTO `Course_Work`.`Nomenclature` (`ID_product`, `Name_product`, `Count`, `Price`, `IDoutlet`, `OutletType`) VALUES (1, 'avocado', 20, 50, 101, 'emporium');
INSERT INTO `Course_Work`.`Nomenclature` (`ID_product`, `Name_product`, `Count`, `Price`, `IDoutlet`, `OutletType`) VALUES (2, 'cheese', 7, 100, 102, 'shop');
INSERT INTO `Course_Work`.`Nomenclature` (`ID_product`, `Name_product`, `Count`, `Price`, `IDoutlet`, `OutletType`) VALUES (3, 'bun', 20, 15, 103, 'kiosk');
INSERT INTO `Course_Work`.`Nomenclature` (`ID_product`, `Name_product`, `Count`, `Price`, `IDoutlet`, `OutletType`) VALUES (3, 'bun', 15, 17, 104, 'stand');
INSERT INTO `Course_Work`.`Nomenclature` (`ID_product`, `Name_product`, `Count`, `Price`, `IDoutlet`, `OutletType`) VALUES (4, 'donut', 25, 16, 104, 'stand');

COMMIT;

START TRANSACTION;
INSERT INTO `Course_Work`.`Accounting` (`ID_Buyer`, `NameBuyer`, `TypeOutlet`, `IDoutlets`, `Product`, `Number`, `Payment`, `Timedata`) VALUES (001, 'Mrs. Grey', 'emporium', 101, 'avocado', 5, 275, '1');
INSERT INTO `Course_Work`.`Accounting` (`ID_Buyer`, `NameBuyer`, `TypeOutlet`, `IDoutlets`, `Product`, `Number`, `Payment`, `Timedata`) VALUES (002, 'Mrs. White', 'shop', 102, 'avocado', 2, 100, '2');
INSERT INTO `Course_Work`.`Accounting` (`ID_Buyer`, `NameBuyer`, `TypeOutlet`, `IDoutlets`, `Product`, `Number`, `Payment`, `Timedata`) VALUES (003, 'Mrs. White', 'shop', 102, 'cheese', 1, 100, '2');

COMMIT;

START TRANSACTION;
INSERT INTO `Course_Work`.`Requests` (`IDrequest`, `Supplier`, `Name_product`, `Number`, `Price`, `WorkTime`) VALUES (1, 'JuicyFruts', 'avocado', 6, 45, 12);
INSERT INTO `Course_Work`.`Requests` (`IDrequest`, `Supplier`, `Name_product`, `Number`, `Price`, `WorkTime`) VALUES (2, 'Desert_Dessert', 'bun', 9, 19, 2);
INSERT INTO `Course_Work`.`Requests` (`IDrequest`, `Supplier`, `Name_product`, `Number`, `Price`, `WorkTime`) VALUES (3, 'NaturalProduction', 'cheese', 7, 42, 2);
INSERT INTO `Course_Work`.`Requests` (`IDrequest`, `Supplier`, `Name_product`, `Number`, `Price`, `WorkTime`) VALUES (4, 'Best_Bakery_Items', 'bun', 5, 15, 6);
INSERT INTO `Course_Work`.`Requests` (`IDrequest`, `Supplier`, `Name_product`, `Number`, `Price`, `WorkTime`) VALUES (5, 'Best_Bakery_Items', 'bun', 20, 15, 3);
INSERT INTO `Course_Work`.`Requests` (`IDrequest`, `Supplier`, `Name_product`, `Number`, `Price`, `WorkTime`) VALUES (6, 'Desert_Dessert', 'donut', 15, 10, 12);
INSERT INTO `Course_Work`.`Requests` (`IDrequest`, `Supplier`, `Name_product`, `Number`, `Price`, `WorkTime`) VALUES (7, 'Desert_Dessert', 'cinnabonroll', 10, 17, 12);

COMMIT;