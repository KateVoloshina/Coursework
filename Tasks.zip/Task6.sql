use course_work;
drop procedure if exists task6;
DELIMITER //
CREATE PROCEDURE Task6 (nam VARCHAR(45), dat INT, outlet VARCHAR(45), id INT)
BEGIN
	SELECT Sold_item, Number FROM sellers where Full_name = nam and Outlets_type = outlet and Work_time = dat and Outlets_id = id;
END //
DELIMITER ;
call Task6 ('Mr. Richard', 2, 'emporium', 101);