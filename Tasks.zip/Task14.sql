use course_work;
drop procedure if exists task14_1;
delimiter $$;
CREATE PROCEDURE Task14_1 (OUT mx INT)
	BEGIN
		SELECT MAX(Number) INTO mx FROM accounting;
	END $$;
CALL Task14_1(@M)$$;
SELECT NameBuyer from accounting where Number=@M$$;

use course_work;
drop procedure if exists task14_2;
delimiter $$;
CREATE PROCEDURE Task14_2 (OUT mex INT)
	BEGIN
		SELECT MAX(Payment) INTO mex FROM accounting;
	END $$;
CALL Task14_2(@M)$$;
SELECT NameBuyer from accounting where Payment=@M$$;