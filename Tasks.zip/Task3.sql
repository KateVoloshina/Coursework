use course_work;
drop procedure if exists task3;
DELIMITER //
CREATE PROCEDURE Task3 (outlet VARCHAR(45), id_outlet INT)
BEGIN
	SELECT Name_product, Count FROM Nomenclature where OutletType = outlet and IDoutlet = id_outlet;
END //
DELIMITER ;
call Task3 ('shop', 102);