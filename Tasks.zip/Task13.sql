use course_work;
drop procedure if exists task13_1;
DELIMITER //
CREATE PROCEDURE Task13_1 (num varchar(45))
BEGIN
    SELECT * FROM accounting where Product = num;
END //
DELIMITER ;
CALL Task13_1 ('avocado');

use course_work;
drop procedure if exists task13_2;
DELIMITER //
CREATE PROCEDURE Task13_2 (num varchar(45), typ varchar(45))
BEGIN
    SELECT * FROM accounting where Product = num and TypeOutlet = typ;
END //
DELIMITER ;
CALL Task13_2 ('cheese', 'shop');

use course_work;
drop procedure if exists task13_3;
DELIMITER //
CREATE PROCEDURE Task13_3 (num varchar(45), typ varchar(45), id INT)
BEGIN
    SELECT * FROM accounting where Product = num and TypeOutlet = typ and IDoutlets = id;
END //
DELIMITER ;
CALL Task13_3 ('avocado', 'shop', 102);