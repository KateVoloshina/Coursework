use course_work;
drop procedure if exists task1_1;
DELIMITER //
CREATE PROCEDURE Task1_1 (item VARCHAR(45))
BEGIN
    SELECT Full_Name FROM Suppliers where Name_product = item;
    SELECT COUNT(Full_Name) FROM Suppliers where Name_product = item;
END //
DELIMITER ;
CALL Task1_1 ('donut');

use course_work;
drop procedure if exists task1_2;
DELIMITER //
CREATE PROCEDURE Task1_2 (num INT)
BEGIN
    SELECT Full_Name FROM Suppliers where MinNumber >= num;
    SELECT COUNT(Full_Name) FROM Suppliers where MinNumber >= num;
END //
DELIMITER ;
CALL Task1_2 (9);

use course_work;
drop procedure if exists task1_3;
DELIMITER //
CREATE PROCEDURE Task1_3 (num INT, dat INT)
BEGIN
    SELECT Full_Name FROM Suppliers where MinNumber >= num and WorkTime = dat;
    SELECT COUNT(Full_Name) FROM Suppliers where MinNumber >= num and WorkTime = dat;
END //
DELIMITER ;
CALL Task1_3 (10, 12);