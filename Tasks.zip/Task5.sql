use course_work;
drop procedure if exists task5_1;
DELIMITER //
CREATE PROCEDURE Task5_1 (dat INT)
BEGIN
	SELECT Sold_item, Number FROM sellers where Work_time = dat;
END //
DELIMITER ;
call Task5_1 (4);

use course_work;
drop procedure if exists task5_2;
DELIMITER //
CREATE PROCEDURE Task5_2 (dat INT, outlet VARCHAR(45))
BEGIN
	SELECT Sold_item, Number FROM sellers where Outlets_type = outlet and Work_time = dat;
END //
DELIMITER ;
call Task5_2 (5, 'stand');